"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Settings,
  Eye,
  ArrowUpDown,
  Filter,
  Grid3X3,
  Upload,
  Download,
  Share,
  Plus,
  ChevronDown,
  Search,
  Bell,
  Check,
  ArrowUp,
  ArrowDown,
  Undo,
  Redo,
  Save,
  Grid,
  List,
  Columns,
  CheckSquare,
  Square,
} from "lucide-react"

interface SpreadsheetToolbarProps {
  onSearch: (query: string) => void
  onFilter: (filters: any) => void
  onSort: (column: string, direction: "asc" | "desc") => void
  onColumnToggle: (column: string) => void
  onAction: (action: string, payload?: any) => void
  onViewModeChange: (mode: "grid" | "list" | "compact") => void
  hiddenColumns: Set<string>
  data: any[]
  viewMode: "grid" | "list" | "compact"
  selectedRows: Set<number>
  canUndo: boolean
  canRedo: boolean
  onUndo: () => void
  onRedo: () => void
}

const columns = [
  { key: "jobRequest", label: "Job Request" },
  { key: "submitted", label: "Submitted" },
  { key: "status", label: "Status" },
  { key: "submitter", label: "Submitter" },
  { key: "url", label: "URL" },
  { key: "assigned", label: "Assigned" },
  { key: "priority", label: "Priority" },
  { key: "dueDate", label: "Due Date" },
  { key: "estValue", label: "Est. Value" },
]

export function SpreadsheetToolbar({
  onSearch,
  onFilter,
  onSort,
  onColumnToggle,
  onAction,
  onViewModeChange,
  hiddenColumns,
  data,
  viewMode,
  selectedRows,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
}: SpreadsheetToolbarProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [openDropdown, setOpenDropdown] = useState<string | null>(null)
  const [activeFilters, setActiveFilters] = useState<any>({})
  const [toolbarMode, setToolbarMode] = useState<"full" | "compact">("full")

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value
    setSearchQuery(query)
    onSearch(query)
  }

  const toggleDropdown = (dropdown: string) => {
    setOpenDropdown(openDropdown === dropdown ? null : dropdown)
  }

  const handleSort = (column: string, direction: "asc" | "desc") => {
    onSort(column, direction)
    setOpenDropdown(null)
    console.log(`Sorted ${column} ${direction}`)
  }

  const handleColumnToggle = (columnKey: string) => {
    onColumnToggle(columnKey)
    console.log(`Toggled column: ${columnKey}`)
  }

  const handleFilter = (column: string, value: string) => {
    const newFilters = { ...activeFilters }
    if (!newFilters[column]) {
      newFilters[column] = []
    }

    if (newFilters[column].includes(value)) {
      newFilters[column] = newFilters[column].filter((v: string) => v !== value)
    } else {
      newFilters[column].push(value)
    }

    if (newFilters[column].length === 0) {
      delete newFilters[column]
    }

    setActiveFilters(newFilters)
    onFilter(newFilters)
    console.log("Applied filters:", newFilters)
  }

  const clearAllFilters = () => {
    setActiveFilters({})
    onFilter({})
    setOpenDropdown(null)
    console.log("Cleared all filters")
  }

  const handleImport = () => {
    const input = document.createElement("input")
    input.type = "file"
    input.accept = ".csv,.xlsx,.json"
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]
      if (file) {
        onAction("import-data", { file })
      }
    }
    input.click()
  }

  const handleExport = (format: "csv" | "xlsx" | "json" = "csv") => {
    onAction("export-data", { format })
  }

  const handleBulkAction = (action: string) => {
    onAction("bulk-action", { action })
    setOpenDropdown(null)
  }

  const getUniqueValues = (column: string) => {
    return [...new Set(data.map((row) => row[column]))].filter(Boolean)
  }

  const handleToolbarCustomization = (mode: "full" | "compact") => {
    setToolbarMode(mode)
    setOpenDropdown(null)
    console.log(`Toolbar mode changed to: ${mode}`)
  }

  return (
    <>
      {/* Main Toolbar */}
      <div className="bg-white border-b border-gray-200 px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-1">
            {/* Quick Actions */}
            <Button
              variant="ghost"
              size="sm"
              className="text-gray-600 hover:text-gray-900 h-8 px-2"
              onClick={() => onAction("save")}
              title="Save (Ctrl+S)"
            >
              <Save className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-gray-600 hover:text-gray-900 h-8 px-2"
              onClick={onUndo}
              disabled={!canUndo}
              title="Undo (Ctrl+Z)"
            >
              <Undo className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-gray-600 hover:text-gray-900 h-8 px-2"
              onClick={onRedo}
              disabled={!canRedo}
              title="Redo (Ctrl+Shift+Z)"
            >
              <Redo className="w-4 h-4" />
            </Button>

            <div className="w-px h-6 bg-gray-300 mx-2" />

            {/* Toolbar Settings */}
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-600 hover:text-gray-900 hover:bg-gray-100 h-8 px-3"
                onClick={() => toggleDropdown("toolbar")}
              >
                <Settings className="w-4 h-4 mr-2" />
                {toolbarMode === "compact" ? "Compact" : "Tool bar"}
                <ChevronDown className="w-3 h-3 ml-1" />
              </Button>
              {openDropdown === "toolbar" && (
                <div className="absolute top-full left-0 z-50 min-w-[200px] bg-white border border-gray-200 rounded-md shadow-lg py-1 mt-1">
                  <div
                    className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100 flex items-center space-x-2"
                    onClick={() => handleToolbarCustomization("full")}
                  >
                    {toolbarMode === "full" && <Check className="w-4 h-4" />}
                    {toolbarMode !== "full" && <div className="w-4 h-4" />}
                    <span>Full Toolbar</span>
                  </div>
                  <div
                    className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100 flex items-center space-x-2"
                    onClick={() => handleToolbarCustomization("compact")}
                  >
                    {toolbarMode === "compact" && <Check className="w-4 h-4" />}
                    {toolbarMode !== "compact" && <div className="w-4 h-4" />}
                    <span>Compact Mode</span>
                  </div>
                  <div className="h-px bg-gray-200 my-1" />
                  <div
                    className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100"
                    onClick={() => {
                      onAction("refresh-data")
                      setOpenDropdown(null)
                    }}
                  >
                    🔄 Reset Layout
                  </div>
                </div>
              )}
            </div>

            {/* Hide Fields */}
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-600 hover:text-gray-900 hover:bg-gray-100 h-8 px-3"
                onClick={() => toggleDropdown("hide")}
              >
                <Eye className="w-4 h-4 mr-2" />
                Hide fields
              </Button>
              {openDropdown === "hide" && (
                <div className="absolute top-full left-0 z-50 min-w-[200px] bg-white border border-gray-200 rounded-md shadow-lg py-1 mt-1">
                  {columns.map((column) => (
                    <div
                      key={column.key}
                      className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100 flex items-center space-x-2"
                      onClick={() => handleColumnToggle(column.key)}
                    >
                      {!hiddenColumns.has(column.key) ? (
                        <CheckSquare className="w-4 h-4 text-green-600" />
                      ) : (
                        <Square className="w-4 h-4 text-gray-400" />
                      )}
                      <span>{column.label}</span>
                    </div>
                  ))}
                  <div className="h-px bg-gray-200 my-1" />
                  <div
                    className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100"
                    onClick={() => {
                      columns.forEach((col) => {
                        if (hiddenColumns.has(col.key)) {
                          handleColumnToggle(col.key)
                        }
                      })
                      setOpenDropdown(null)
                    }}
                  >
                    👁️ Show All Columns
                  </div>
                  <div
                    className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100"
                    onClick={() => {
                      columns.slice(3).forEach((col) => handleColumnToggle(col.key))
                      setOpenDropdown(null)
                    }}
                  >
                    📱 Mobile View (Hide Optional)
                  </div>
                </div>
              )}
            </div>

            {/* Sort */}
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-600 hover:text-gray-900 hover:bg-gray-100 h-8 px-3"
                onClick={() => toggleDropdown("sort")}
              >
                <ArrowUpDown className="w-4 h-4 mr-2" />
                Sort
              </Button>
              {openDropdown === "sort" && (
                <div className="absolute top-full left-0 z-50 min-w-[200px] bg-white border border-gray-200 rounded-md shadow-lg py-1 mt-1 max-h-96 overflow-y-auto">
                  {columns
                    .filter((col) => !hiddenColumns.has(col.key))
                    .map((column) => (
                      <div key={column.key}>
                        <div className="px-3 py-1 text-xs font-medium text-gray-500 uppercase bg-gray-50">
                          {column.label}
                        </div>
                        <div
                          className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100 flex items-center space-x-2"
                          onClick={() => handleSort(column.key, "asc")}
                        >
                          <ArrowUp className="w-4 h-4" />
                          <span>A → Z (Ascending)</span>
                        </div>
                        <div
                          className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100 flex items-center space-x-2"
                          onClick={() => handleSort(column.key, "desc")}
                        >
                          <ArrowDown className="w-4 h-4" />
                          <span>Z → A (Descending)</span>
                        </div>
                        <div className="h-px bg-gray-200 my-1" />
                      </div>
                    ))}
                  <div
                    className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100"
                    onClick={() => {
                      onSort("", "asc")
                      setOpenDropdown(null)
                    }}
                  >
                    🔄 Clear Sort
                  </div>
                </div>
              )}
            </div>

            {/* Filter */}
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-600 hover:text-gray-900 hover:bg-gray-100 h-8 px-3"
                onClick={() => toggleDropdown("filter")}
              >
                <Filter className="w-4 h-4 mr-2" />
                Filter
                {Object.keys(activeFilters).length > 0 && (
                  <span className="ml-1 bg-blue-500 text-white text-xs rounded-full px-1.5 py-0.5">
                    {Object.keys(activeFilters).length}
                  </span>
                )}
              </Button>
              {openDropdown === "filter" && (
                <div className="absolute top-full left-0 z-50 w-72 bg-white border border-gray-200 rounded-md shadow-lg py-1 mt-1 max-h-96 overflow-y-auto">
                  <div className="px-3 py-2">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-sm font-medium">Active Filters</span>
                      {Object.keys(activeFilters).length > 0 && (
                        <button
                          onClick={clearAllFilters}
                          className="text-xs text-blue-600 hover:text-blue-800 px-2 py-1 rounded hover:bg-blue-50"
                        >
                          Clear All
                        </button>
                      )}
                    </div>

                    {/* Status Filter */}
                    <div className="mb-4">
                      <div className="text-xs font-medium text-gray-500 mb-2 uppercase">Status</div>
                      {getUniqueValues("status").map((status) => (
                        <label key={status} className="flex items-center space-x-2 py-1 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={activeFilters.status?.includes(status) || false}
                            onChange={() => handleFilter("status", status)}
                            className="rounded border-gray-300"
                          />
                          <span className="text-sm">{status}</span>
                          <span className="text-xs text-gray-400">
                            ({data.filter((row) => row.status === status).length})
                          </span>
                        </label>
                      ))}
                    </div>

                    {/* Priority Filter */}
                    <div className="mb-4">
                      <div className="text-xs font-medium text-gray-500 mb-2 uppercase">Priority</div>
                      {getUniqueValues("priority").map((priority) => (
                        <label key={priority} className="flex items-center space-x-2 py-1 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={activeFilters.priority?.includes(priority) || false}
                            onChange={() => handleFilter("priority", priority)}
                            className="rounded border-gray-300"
                          />
                          <span className="text-sm">{priority}</span>
                          <span className="text-xs text-gray-400">
                            ({data.filter((row) => row.priority === priority).length})
                          </span>
                        </label>
                      ))}
                    </div>

                    {/* Submitter Filter */}
                    <div className="mb-4">
                      <div className="text-xs font-medium text-gray-500 mb-2 uppercase">Submitter</div>
                      {getUniqueValues("submitter").map((submitter) => (
                        <label key={submitter} className="flex items-center space-x-2 py-1 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={activeFilters.submitter?.includes(submitter) || false}
                            onChange={() => handleFilter("submitter", submitter)}
                            className="rounded border-gray-300"
                          />
                          <span className="text-sm">{submitter}</span>
                        </label>
                      ))}
                    </div>

                    {/* Quick Filter Actions */}
                    <div className="border-t pt-2 mt-2">
                      <div className="text-xs font-medium text-gray-500 mb-2">Quick Filters</div>
                      <div className="space-y-1">
                        <button
                          className="w-full text-left text-sm px-2 py-1 rounded hover:bg-gray-100"
                          onClick={() => {
                            handleFilter("status", "Complete")
                            setOpenDropdown(null)
                          }}
                        >
                          ✅ Show Completed Only
                        </button>
                        <button
                          className="w-full text-left text-sm px-2 py-1 rounded hover:bg-gray-100"
                          onClick={() => {
                            handleFilter("priority", "High")
                            setOpenDropdown(null)
                          }}
                        >
                          🔥 High Priority Only
                        </button>
                        <button
                          className="w-full text-left text-sm px-2 py-1 rounded hover:bg-gray-100"
                          onClick={() => {
                            handleFilter("status", "Blocked")
                            setOpenDropdown(null)
                          }}
                        >
                          🚫 Blocked Items Only
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Cell View */}
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-600 hover:text-gray-900 hover:bg-gray-100 h-8 px-3"
                onClick={() => toggleDropdown("view")}
              >
                <Grid3X3 className="w-4 h-4 mr-2" />
                View
              </Button>
              {openDropdown === "view" && (
                <div className="absolute top-full left-0 z-50 min-w-[180px] bg-white border border-gray-200 rounded-md shadow-lg py-1 mt-1">
                  <div
                    className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100 flex items-center space-x-2"
                    onClick={() => {
                      onViewModeChange("grid")
                      setOpenDropdown(null)
                    }}
                  >
                    <Grid className="w-4 h-4" />
                    <span>Grid View</span>
                    {viewMode === "grid" && <Check className="w-4 h-4 ml-auto text-blue-600" />}
                  </div>
                  <div
                    className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100 flex items-center space-x-2"
                    onClick={() => {
                      onViewModeChange("list")
                      setOpenDropdown(null)
                    }}
                  >
                    <List className="w-4 h-4" />
                    <span>List View</span>
                    {viewMode === "list" && <Check className="w-4 h-4 ml-auto text-blue-600" />}
                  </div>
                  <div
                    className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100 flex items-center space-x-2"
                    onClick={() => {
                      onViewModeChange("compact")
                      setOpenDropdown(null)
                    }}
                  >
                    <Columns className="w-4 h-4" />
                    <span>Compact View</span>
                    {viewMode === "compact" && <Check className="w-4 h-4 ml-auto text-blue-600" />}
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Bulk Actions (when rows selected) */}
            {selectedRows.size > 0 && (
              <>
                <div className="relative">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-blue-600 hover:text-blue-800 hover:bg-blue-50 h-8 px-3"
                    onClick={() => toggleDropdown("bulk")}
                  >
                    <CheckSquare className="w-4 h-4 mr-2" />
                    {selectedRows.size} selected
                    <ChevronDown className="w-3 h-3 ml-1" />
                  </Button>
                  {openDropdown === "bulk" && (
                    <div className="absolute top-full right-0 z-50 min-w-[200px] bg-white border border-gray-200 rounded-md shadow-lg py-1 mt-1">
                      <div
                        className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100"
                        onClick={() => handleBulkAction("mark-complete")}
                      >
                        ✅ Mark as Complete
                      </div>
                      <div
                        className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100"
                        onClick={() => handleBulkAction("mark-in-progress")}
                      >
                        🔄 Mark as In Progress
                      </div>
                      <div
                        className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100"
                        onClick={() => handleBulkAction("mark-blocked")}
                      >
                        🚫 Mark as Blocked
                      </div>
                      <div className="h-px bg-gray-200 my-1" />
                      <div
                        className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100"
                        onClick={() => handleBulkAction("set-high-priority")}
                      >
                        🔥 Set High Priority
                      </div>
                      <div
                        className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100"
                        onClick={() => handleBulkAction("duplicate")}
                      >
                        📋 Duplicate Rows
                      </div>
                      <div className="h-px bg-gray-200 my-1" />
                      <div
                        className="px-3 py-2 text-sm cursor-pointer hover:bg-red-100 text-red-600"
                        onClick={() => {
                          if (confirm(`Delete ${selectedRows.size} selected rows?`)) {
                            onAction("delete-rows")
                          }
                          setOpenDropdown(null)
                        }}
                      >
                        🗑️ Delete Selected
                      </div>
                    </div>
                  )}
                </div>
                <div className="w-px h-6 bg-gray-300" />
              </>
            )}

            {/* Standard Actions */}
            <Button
              variant="ghost"
              size="sm"
              className="text-gray-600 hover:text-gray-900 hover:bg-gray-100 h-8 px-3"
              onClick={handleImport}
            >
              <Upload className="w-4 h-4 mr-2" />
              Import
            </Button>

            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-600 hover:text-gray-900 hover:bg-gray-100 h-8 px-3"
                onClick={() => toggleDropdown("export")}
              >
                <Download className="w-4 h-4 mr-2" />
                Export
                <ChevronDown className="w-3 h-3 ml-1" />
              </Button>
              {openDropdown === "export" && (
                <div className="absolute top-full right-0 z-50 min-w-[150px] bg-white border border-gray-200 rounded-md shadow-lg py-1 mt-1">
                  <div
                    className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100"
                    onClick={() => {
                      handleExport("csv")
                      setOpenDropdown(null)
                    }}
                  >
                    📄 Export as CSV
                  </div>
                  <div
                    className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100"
                    onClick={() => {
                      handleExport("xlsx")
                      setOpenDropdown(null)
                    }}
                  >
                    📊 Export as Excel
                  </div>
                  <div
                    className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100"
                    onClick={() => {
                      handleExport("json")
                      setOpenDropdown(null)
                    }}
                  >
                    🔧 Export as JSON
                  </div>
                  <div className="h-px bg-gray-200 my-1" />
                  <div
                    className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100"
                    onClick={() => {
                      onAction("print")
                      setOpenDropdown(null)
                    }}
                  >
                    🖨️ Print
                  </div>
                </div>
              )}
            </div>

            <Button
              variant="ghost"
              size="sm"
              className="text-gray-600 hover:text-gray-900 hover:bg-gray-100 h-8 px-3"
              onClick={() => onAction("share")}
            >
              <Share className="w-4 h-4 mr-2" />
              Share
            </Button>

            <Button
              className="bg-green-600 hover:bg-green-700 text-white h-8 px-3"
              onClick={() => onAction("new-action")}
            >
              <Plus className="w-4 h-4 mr-2" />
              New Action
            </Button>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-white px-6 py-3 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search within sheet..."
              value={searchQuery}
              onChange={handleSearchChange}
              className="pl-10 bg-gray-50 border-gray-200 h-9 w-80"
            />
            {searchQuery && (
              <button
                onClick={() => {
                  setSearchQuery("")
                  onSearch("")
                }}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            )}
          </div>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="text-gray-600 h-8" onClick={() => onAction("notifications")}>
              <Bell className="w-4 h-4 mr-2" />
              <span className="bg-red-500 text-white text-xs rounded-full px-1.5 py-0.5">3</span>
            </Button>
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs">
                JD
              </div>
              <span>John Doe</span>
            </div>
          </div>
        </div>
      </div>

      {/* Active Filters Display */}
      {Object.keys(activeFilters).length > 0 && (
        <div className="bg-blue-50 px-6 py-2 border-b border-blue-200">
          <div className="flex items-center space-x-2 flex-wrap">
            <span className="text-sm text-blue-700 font-medium">Active Filters:</span>
            {Object.entries(activeFilters).map(([column, values]) => (
              <span
                key={column}
                className="inline-flex items-center text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full"
              >
                {column}: {(values as string[]).join(", ")}
                <button
                  onClick={() => {
                    const newFilters = { ...activeFilters }
                    delete newFilters[column]
                    setActiveFilters(newFilters)
                    onFilter(newFilters)
                  }}
                  className="ml-1 text-blue-600 hover:text-blue-800"
                >
                  ✕
                </button>
              </span>
            ))}
            <button
              onClick={clearAllFilters}
              className="text-xs text-blue-700 hover:text-blue-800 px-2 py-1 rounded hover:bg-blue-100"
            >
              Clear All
            </button>
          </div>
        </div>
      )}
    </>
  )
}
