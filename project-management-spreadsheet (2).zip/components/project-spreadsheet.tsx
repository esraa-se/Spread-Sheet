"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  Settings,
  Eye,
  ArrowUpDown,
  Filter,
  Grid3X3,
  Upload,
  Download,
  Share,
  Plus,
  ChevronDown,
  Home,
  ChevronRight,
} from "lucide-react"

interface TaskData {
  id: number
  jobRequest: string
  submitted: string
  status: "In-progress" | "Complete" | "Blocked"
  submitter: string
  url: string
  assigned: string
  priority: "Low" | "Medium" | "High"
  dueDate: string
  estValue: string
}

const mockData: TaskData[] = [
  {
    id: 1,
    jobRequest: "Launch social media campaign for pro...",
    submitted: "15-11-2024",
    status: "In-progress",
    submitter: "Aisha Patel",
    url: "www.aishapatel...",
    assigned: "Sophie Choudhury",
    priority: "Medium",
    dueDate: "30-11-2024",
    estValue: "6,200,000",
  },
  {
    id: 2,
    jobRequest: "Update pricing kit for company redesign",
    submitted: "28-10-2024",
    status: "Complete",
    submitter: "Ifan Khan",
    url: "www.ifankhan...",
    assigned: "Tess Pensley",
    priority: "High",
    dueDate: "30-10-2024",
    estValue: "3,200,000",
  },
  {
    id: 3,
    jobRequest: "Finalize user testing feedback for app...",
    submitted: "05-12-2024",
    status: "In-progress",
    submitter: "Mark Johnson",
    url: "www.markjohns...",
    assigned: "Rachel Lee",
    priority: "Medium",
    dueDate: "10-12-2024",
    estValue: "4,750,000",
  },
  {
    id: 4,
    jobRequest: "Design new features for the website",
    submitted: "10-01-2025",
    status: "Complete",
    submitter: "Emily Green",
    url: "www.emilygreen...",
    assigned: "Tom Wright",
    priority: "Low",
    dueDate: "15-01-2025",
    estValue: "5,900,000",
  },
  {
    id: 5,
    jobRequest: "Prepare financial report for Q4",
    submitted: "25-01-2025",
    status: "Blocked",
    submitter: "Jessica Brown",
    url: "www.jessicabr...",
    assigned: "Kevin Smith",
    priority: "Low",
    dueDate: "30-01-2025",
    estValue: "2,800,000",
  },
]

const getStatusColor = (status: string) => {
  switch (status) {
    case "Complete":
      return "bg-green-100 text-green-800 border-green-200"
    case "In-progress":
      return "bg-orange-100 text-orange-800 border-orange-200"
    case "Blocked":
      return "bg-red-100 text-red-800 border-red-200"
    default:
      return "bg-gray-100 text-gray-800 border-gray-200"
  }
}

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case "High":
      return "bg-red-100 text-red-800 border-red-200"
    case "Medium":
      return "bg-orange-100 text-orange-800 border-orange-200"
    case "Low":
      return "bg-blue-100 text-blue-800 border-blue-200"
    default:
      return "bg-gray-100 text-gray-800 border-gray-200"
  }
}

export function ProjectSpreadsheet() {
  const [data, setData] = useState<TaskData[]>(mockData)

  return (
    <div className="flex h-screen bg-white">
      {/* Sidebar */}
      <div className="w-64 bg-gray-900 text-white p-4">
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-4">Intern Design Assignment</h2>
          <div className="space-y-2">
            <div className="text-sm text-gray-300">Pages</div>
            <div className="pl-4">
              <div className="text-sm py-1 text-blue-400">Page 1</div>
            </div>
            <div className="text-sm text-gray-300 mt-4">Layers</div>
            <div className="pl-4 space-y-1">
              <div className="text-sm py-1 text-gray-400">Note</div>
              <div className="text-sm py-1 text-gray-400">Spreadsheet style</div>
              <div className="text-sm py-1 bg-blue-600 px-2 rounded">Working area</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-purple-700 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-white/20 rounded-lg p-2">
                <div className="w-6 h-6 bg-white/40 rounded"></div>
              </div>
              <div>
                <div className="text-white font-medium">Spreadsheet style</div>
                <div className="text-purple-200 text-sm">Vineeth Pal K</div>
              </div>
            </div>
          </div>
        </div>

        {/* Breadcrumb */}
        <div className="bg-gray-50 px-6 py-3 border-b">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Home className="w-4 h-4" />
            <span>Workspace</span>
            <ChevronRight className="w-4 h-4" />
            <span>Folder 2</span>
            <ChevronRight className="w-4 h-4" />
            <span className="text-gray-900 font-medium">Spreadsheet 3</span>
          </div>
        </div>

        {/* Toolbar */}
        <div className="bg-white border-b px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="text-gray-600">
                <Settings className="w-4 h-4 mr-2" />
                Tool bar
                <ChevronDown className="w-4 h-4 ml-1" />
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600">
                <Eye className="w-4 h-4 mr-2" />
                Hide fields
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600">
                <ArrowUpDown className="w-4 h-4 mr-2" />
                Sort
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600">
                <Grid3X3 className="w-4 h-4 mr-2" />
                Cell view
              </Button>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm" className="text-gray-600">
                <Upload className="w-4 h-4 mr-2" />
                Import
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600">
                <Share className="w-4 h-4 mr-2" />
                Share
              </Button>
              <Button className="bg-green-600 hover:bg-green-700 text-white">
                <Plus className="w-4 h-4 mr-2" />
                New Action
              </Button>
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="bg-white px-6 py-3 border-b">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input placeholder="Search within sheet" className="pl-10 bg-gray-50 border-gray-200" />
          </div>
        </div>

        {/* Table */}
        <div className="flex-1 overflow-auto">
          <div className="min-w-full">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-8">
                    #
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Job Request
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Submitted
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Submitter
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    URL
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Assigned
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Priority
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Due Date
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Est. Value
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {data.map((row, index) => (
                  <tr key={row.id} className="hover:bg-gray-50">
                    <td className="px-4 py-4 text-sm text-gray-500">{index + 1}</td>
                    <td className="px-4 py-4 text-sm text-gray-900 max-w-xs">
                      <div className="truncate">{row.jobRequest}</div>
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-900">{row.submitted}</td>
                    <td className="px-4 py-4">
                      <Badge className={`${getStatusColor(row.status)} border`}>{row.status}</Badge>
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-900">{row.submitter}</td>
                    <td className="px-4 py-4 text-sm text-blue-600 hover:text-blue-800">
                      <a href="#" className="truncate block max-w-32">
                        {row.url}
                      </a>
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-900">{row.assigned}</td>
                    <td className="px-4 py-4">
                      <Badge className={`${getPriorityColor(row.priority)} border`}>{row.priority}</Badge>
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-900">{row.dueDate}</td>
                    <td className="px-4 py-4 text-sm text-gray-900">{row.estValue}</td>
                  </tr>
                ))}
                {/* Empty rows */}
                {Array.from({ length: 15 }, (_, i) => (
                  <tr key={`empty-${i}`} className="hover:bg-gray-50">
                    <td className="px-4 py-4 text-sm text-gray-400">{data.length + i + 1}</td>
                    {Array.from({ length: 9 }, (_, j) => (
                      <td key={j} className="px-4 py-4 text-sm text-gray-300">
                        <div className="h-4"></div>
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
