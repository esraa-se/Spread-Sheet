"use client"

import type React from "react"
import { useState, useCallback, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import type { TaskRow, SortState } from "@/types/spreadsheet"
import { ArrowUpDown, ArrowUp, ArrowDown, Check, X } from "lucide-react"

interface SpreadsheetTableProps {
  data: TaskRow[]
  onCellSelect: (row: number, col: string) => void
  onCellEdit: (row: number, col: string, value: string) => void
  onSort: (column: keyof TaskRow) => void
  selectedCell: { row: number; col: string } | null
  selectedRows: Set<number>
  onRowSelect: (rows: Set<number>) => void
  sortState: SortState
  hiddenColumns: Set<string>
  viewMode: "grid" | "list" | "compact"
  editingCell: { row: number; col: string; value: string } | null
  onEditingCell: (cell: { row: number; col: string; value: string } | null) => void
}

const columns = [
  { key: "jobRequest" as keyof TaskRow, label: "Job Request", width: "w-80" },
  { key: "submitted" as keyof TaskRow, label: "Submitted", width: "w-32" },
  { key: "status" as keyof TaskRow, label: "Status", width: "w-32" },
  { key: "submitter" as keyof TaskRow, label: "Submitter", width: "w-36" },
  { key: "url" as keyof TaskRow, label: "URL", width: "w-36" },
  { key: "assigned" as keyof TaskRow, label: "Assigned", width: "w-36" },
  { key: "priority" as keyof TaskRow, label: "Priority", width: "w-28" },
  { key: "dueDate" as keyof TaskRow, label: "Due Date", width: "w-32" },
  { key: "estValue" as keyof TaskRow, label: "Est. Value", width: "w-32" },
]

const getStatusColor = (status: string) => {
  switch (status) {
    case "Complete":
      return "bg-green-100 text-green-800 border-green-200"
    case "In-progress":
      return "bg-orange-100 text-orange-800 border-orange-200"
    case "Blocked":
      return "bg-red-100 text-red-800 border-red-200"
    default:
      return "bg-gray-100 text-gray-800 border-gray-200"
  }
}

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case "High":
      return "bg-red-100 text-red-800 border-red-200"
    case "Medium":
      return "bg-orange-100 text-orange-800 border-orange-200"
    case "Low":
      return "bg-blue-100 text-blue-800 border-blue-200"
    default:
      return "bg-gray-100 text-gray-800 border-gray-200"
  }
}

export function SpreadsheetTable({
  data,
  onCellSelect,
  onCellEdit,
  onSort,
  selectedCell,
  selectedRows,
  onRowSelect,
  sortState,
  hiddenColumns,
  viewMode,
  editingCell,
  onEditingCell,
}: SpreadsheetTableProps) {
  const [selectedRow, setSelectedRow] = useState<number | null>(null)
  const [selectedCol, setSelectedCol] = useState<string | null>(null)

  const handleCellClick = useCallback(
    (rowIndex: number, colKey: string, currentValue: string) => {
      setSelectedRow(rowIndex)
      setSelectedCol(colKey)
      onCellSelect(rowIndex, colKey)
      console.log(`Selected cell [${rowIndex}, ${colKey}] with value: ${currentValue}`)
    },
    [onCellSelect],
  )

  const handleCellDoubleClick = useCallback(
    (rowIndex: number, colKey: string, currentValue: string) => {
      onEditingCell({ row: rowIndex, col: colKey, value: currentValue })
      console.log(`Started editing cell [${rowIndex}, ${colKey}]`)
    },
    [onEditingCell],
  )

  const handleEditSave = useCallback(() => {
    if (editingCell) {
      onCellEdit(editingCell.row, editingCell.col, editingCell.value)
      onEditingCell(null)
    }
  }, [editingCell, onCellEdit, onEditingCell])

  const handleEditCancel = useCallback(() => {
    onEditingCell(null)
  }, [onEditingCell])

  const handleRowSelect = useCallback(
    (rowIndex: number, isCtrlPressed: boolean) => {
      const newSelectedRows = new Set(selectedRows)

      if (isCtrlPressed) {
        if (newSelectedRows.has(rowIndex)) {
          newSelectedRows.delete(rowIndex)
        } else {
          newSelectedRows.add(rowIndex)
        }
      } else {
        newSelectedRows.clear()
        newSelectedRows.add(rowIndex)
      }

      onRowSelect(newSelectedRows)
      console.log(`Selected rows: ${Array.from(newSelectedRows).join(", ")}`)
    },
    [selectedRows, onRowSelect],
  )

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (editingCell) {
        if (e.key === "Enter") {
          e.preventDefault()
          handleEditSave()
        } else if (e.key === "Escape") {
          e.preventDefault()
          handleEditCancel()
        }
        return
      }

      if (selectedRow === null || selectedCol === null) return

      const visibleColumns = columns.filter((col) => !hiddenColumns.has(col.key))
      const currentColIndex = visibleColumns.findIndex((col) => col.key === selectedCol)

      switch (e.key) {
        case "ArrowUp":
          e.preventDefault()
          if (selectedRow > 0) {
            handleCellClick(selectedRow - 1, selectedCol, data[selectedRow - 1][selectedCol])
          }
          break
        case "ArrowDown":
          e.preventDefault()
          if (selectedRow < data.length - 1) {
            handleCellClick(selectedRow + 1, selectedCol, data[selectedRow + 1][selectedCol])
          }
          break
        case "ArrowLeft":
          e.preventDefault()
          if (currentColIndex > 0) {
            handleCellClick(
              selectedRow,
              visibleColumns[currentColIndex - 1].key,
              data[selectedRow][visibleColumns[currentColIndex - 1].key],
            )
          }
          break
        case "ArrowRight":
          e.preventDefault()
          if (currentColIndex < visibleColumns.length - 1) {
            handleCellClick(
              selectedRow,
              visibleColumns[currentColIndex + 1].key,
              data[selectedRow][visibleColumns[currentColIndex + 1].key],
            )
          }
          break
        case "Enter":
        case "F2":
          e.preventDefault()
          if (selectedRow < data.length) {
            handleCellDoubleClick(selectedRow, selectedCol, data[selectedRow][selectedCol])
          }
          break
      }
    },
    [
      selectedRow,
      selectedCol,
      data,
      hiddenColumns,
      editingCell,
      handleCellClick,
      handleCellDoubleClick,
      handleEditSave,
      handleEditCancel,
    ],
  )

  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if (selectedRow !== null && selectedCol !== null) {
        handleKeyDown(e as any)
      }
    }

    document.addEventListener("keydown", handleGlobalKeyDown)
    return () => document.removeEventListener("keydown", handleGlobalKeyDown)
  }, [handleKeyDown, selectedRow, selectedCol])

  const renderSortIcon = (column: keyof TaskRow) => {
    if (sortState.column !== column) {
      return <ArrowUpDown className="w-3 h-3 text-gray-400" />
    }
    return sortState.direction === "asc" ? (
      <ArrowUp className="w-3 h-3 text-blue-600" />
    ) : (
      <ArrowDown className="w-3 h-3 text-blue-600" />
    )
  }

  const renderCell = (row: TaskRow, column: any, rowIndex: number) => {
    const isEditing = editingCell?.row === rowIndex && editingCell?.col === column.key
    const isSelected = selectedRow === rowIndex && selectedCol === column.key

    if (isEditing) {
      return (
        <div className="flex items-center space-x-1">
          <Input
            value={editingCell.value}
            onChange={(e) => onEditingCell({ ...editingCell, value: e.target.value })}
            className="h-6 text-xs"
            autoFocus
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault()
                handleEditSave()
              } else if (e.key === "Escape") {
                e.preventDefault()
                handleEditCancel()
              }
            }}
          />
          <button onClick={handleEditSave} className="text-green-600 hover:text-green-800">
            <Check className="w-3 h-3" />
          </button>
          <button onClick={handleEditCancel} className="text-red-600 hover:text-red-800">
            <X className="w-3 h-3" />
          </button>
        </div>
      )
    }

    const cellContent = (() => {
      switch (column.key) {
        case "status":
          return <Badge className={`${getStatusColor(row[column.key])} border text-xs`}>{row[column.key]}</Badge>
        case "priority":
          return <Badge className={`${getPriorityColor(row[column.key])} border text-xs`}>{row[column.key]}</Badge>
        case "url":
          return (
            <a
              href="#"
              className="text-blue-600 hover:text-blue-800 truncate block"
              onClick={(e) => {
                e.preventDefault()
                console.log(`Clicked URL: ${row[column.key]}`)
                window.open(`https://${row[column.key]}`, "_blank")
              }}
            >
              {row[column.key]}
            </a>
          )
        case "jobRequest":
          return (
            <div className="truncate max-w-xs" title={row[column.key]}>
              {row[column.key]}
            </div>
          )
        default:
          return <span className="text-gray-900">{row[column.key]}</span>
      }
    })()

    return (
      <div
        className={`cursor-cell ${isSelected ? "ring-2 ring-blue-500 ring-inset" : ""}`}
        onClick={() => handleCellClick(rowIndex, column.key, row[column.key])}
        onDoubleClick={() => handleCellDoubleClick(rowIndex, column.key, row[column.key])}
      >
        {cellContent}
      </div>
    )
  }

  const visibleColumns = columns.filter((col) => !hiddenColumns.has(col.key))

  const getTableClasses = () => {
    switch (viewMode) {
      case "compact":
        return "text-xs"
      case "list":
        return "text-sm"
      default:
        return "text-sm"
    }
  }

  const getCellPadding = () => {
    switch (viewMode) {
      case "compact":
        return "px-2 py-1"
      case "list":
        return "px-3 py-2"
      default:
        return "px-4 py-3"
    }
  }

  return (
    <div className="flex-1 overflow-auto bg-white">
      <div className="min-w-full">
        <table className={`w-full border-collapse ${getTableClasses()}`}>
          <thead className="bg-gray-50 sticky top-0 z-10">
            <tr>
              <th
                className={`w-12 ${getCellPadding()} text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-r border-gray-200`}
              >
                <input
                  type="checkbox"
                  checked={selectedRows.size === data.length && data.length > 0}
                  onChange={(e) => {
                    if (e.target.checked) {
                      onRowSelect(new Set(data.map((_, index) => index)))
                    } else {
                      onRowSelect(new Set())
                    }
                  }}
                  className="rounded"
                />
              </th>
              {visibleColumns.map((column) => (
                <th
                  key={column.key}
                  className={`${column.width} ${getCellPadding()} text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-r border-gray-200 cursor-pointer hover:bg-gray-100`}
                  onClick={() => onSort(column.key)}
                >
                  <div className="flex items-center space-x-2">
                    <span>{column.label}</span>
                    {renderSortIcon(column.key)}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white">
            {data.map((row, rowIndex) => (
              <tr
                key={row.id}
                className={`hover:bg-gray-50 ${selectedRows.has(rowIndex) ? "bg-blue-50" : ""} ${
                  selectedRow === rowIndex ? "bg-blue-50" : ""
                }`}
              >
                <td className={`${getCellPadding()} border-b border-r border-gray-200 bg-gray-50`}>
                  <input
                    type="checkbox"
                    checked={selectedRows.has(rowIndex)}
                    onChange={(e) => handleRowSelect(rowIndex, e.ctrlKey || e.metaKey)}
                    className="rounded"
                  />
                </td>
                {visibleColumns.map((column) => (
                  <td
                    key={`${row.id}-${column.key}`}
                    className={`${getCellPadding()} border-b border-r border-gray-200`}
                  >
                    {renderCell(row, column, rowIndex)}
                  </td>
                ))}
              </tr>
            ))}

            {/* Empty rows for spreadsheet feel */}
            {Array.from({ length: Math.max(0, 20 - data.length) }, (_, i) => (
              <tr key={`empty-${i}`} className="hover:bg-gray-50">
                <td className={`${getCellPadding()} text-gray-400 border-b border-r border-gray-200 bg-gray-50`}>
                  <input type="checkbox" disabled className="rounded opacity-50" />
                </td>
                {visibleColumns.map((column) => (
                  <td
                    key={`empty-${i}-${column.key}`}
                    className={`${getCellPadding()} border-b border-r border-gray-200 cursor-cell`}
                    onClick={() => handleCellClick(data.length + i, column.key, "")}
                  >
                    <div className="h-5"></div>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
