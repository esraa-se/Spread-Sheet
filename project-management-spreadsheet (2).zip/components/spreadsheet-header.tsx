"use client"

import { Home, ChevronRight, Bell, User, HelpCircle } from "lucide-react"

export function SpreadsheetHeader() {
  const handleBreadcrumbClick = (item: string) => {
    console.log(`Navigating to: ${item}`)
    alert(`Navigating to ${item}`)
  }

  const handleNotificationClick = () => {
    console.log("Notifications opened")
    alert("Notifications: You have 3 new updates!")
  }

  const handleUserClick = () => {
    console.log("User menu opened")
    alert("User menu: Profile, Settings, Logout")
  }

  const handleHelpClick = () => {
    console.log("Help opened")
    alert("Help: Documentation and tutorials available!")
  }

  return (
    <>
      {/* Purple Header */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-700 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="bg-white/20 rounded-lg p-2">
              <div className="w-6 h-6 bg-white/40 rounded flex items-center justify-center">
                <span className="text-white text-xs font-bold">📊</span>
              </div>
            </div>
            <div>
              <div className="text-white font-medium text-lg">Spreadsheet style</div>
              <div className="text-purple-200 text-sm">Vineeth Pal K</div>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button
              className="text-white/80 hover:text-white p-2 rounded hover:bg-white/10"
              onClick={handleHelpClick}
              title="Help"
            >
              <HelpCircle className="w-5 h-5" />
            </button>
            <button
              className="text-white/80 hover:text-white p-2 rounded hover:bg-white/10"
              onClick={handleNotificationClick}
              title="Notifications"
            >
              <Bell className="w-5 h-5" />
            </button>
            <button
              className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30"
              onClick={handleUserClick}
              title="User menu"
            >
              <User className="w-4 h-4 text-white" />
            </button>
          </div>
        </div>
      </div>

      {/* Breadcrumb */}
      <div className="bg-gray-50 px-6 py-3 border-b border-gray-200">
        <div className="flex items-center space-x-2 text-sm">
          <button
            className="flex items-center text-gray-600 hover:text-gray-900 p-1 rounded hover:bg-gray-200"
            onClick={() => handleBreadcrumbClick("Home")}
          >
            <Home className="w-4 h-4" />
          </button>
          <ChevronRight className="w-4 h-4 text-gray-400" />
          <button
            className="text-gray-600 hover:text-gray-900 px-2 py-1 rounded hover:bg-gray-200"
            onClick={() => handleBreadcrumbClick("Workspace")}
          >
            Workspace
          </button>
          <ChevronRight className="w-4 h-4 text-gray-400" />
          <button
            className="text-gray-600 hover:text-gray-900 px-2 py-1 rounded hover:bg-gray-200"
            onClick={() => handleBreadcrumbClick("Folder 2")}
          >
            Folder 2
          </button>
          <ChevronRight className="w-4 h-4 text-gray-400" />
          <span className="text-gray-900 font-medium">Spreadsheet 3</span>
        </div>
      </div>
    </>
  )
}
