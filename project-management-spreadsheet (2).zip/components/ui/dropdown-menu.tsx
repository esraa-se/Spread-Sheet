"use client"

import * as React from "react"
import { cn } from "@/lib/utils"

interface DropdownMenuProps {
  children: React.ReactNode
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function DropdownMenu({ children, open, onOpenChange }: DropdownMenuProps) {
  return (
    <div className="relative">
      {React.Children.map(children, (child) =>
        React.isValidElement(child) ? React.cloneElement(child, { open, onOpenChange } as any) : child,
      )}
    </div>
  )
}

interface DropdownMenuTriggerProps {
  children: React.ReactNode
  open?: boolean
  onOpenChange?: (open: boolean) => void
}

export function DropdownMenuTrigger({ children, open, onOpenChange }: DropdownMenuTriggerProps) {
  return <div onClick={() => onOpenChange?.(!open)}>{children}</div>
}

interface DropdownMenuContentProps {
  children: React.ReactNode
  open?: boolean
  className?: string
}

export function DropdownMenuContent({ children, open, className }: DropdownMenuContentProps) {
  if (!open) return null

  return (
    <div
      className={cn(
        "absolute top-full left-0 z-50 min-w-[200px] bg-white border border-gray-200 rounded-md shadow-lg py-1 mt-1",
        className,
      )}
    >
      {children}
    </div>
  )
}

interface DropdownMenuItemProps {
  children: React.ReactNode
  onClick?: () => void
  className?: string
}

export function DropdownMenuItem({ children, onClick, className }: DropdownMenuItemProps) {
  return (
    <div
      className={cn("px-3 py-2 text-sm cursor-pointer hover:bg-gray-100 flex items-center space-x-2", className)}
      onClick={onClick}
    >
      {children}
    </div>
  )
}

export function DropdownMenuSeparator() {
  return <div className="h-px bg-gray-200 my-1" />
}
