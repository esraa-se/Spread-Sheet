"use client"

import { useState, useCallback, useEffect } from "react"
import { SpreadsheetHeader } from "./spreadsheet-header"
import { SpreadsheetToolbar } from "./spreadsheet-toolbar"
import { SpreadsheetTable } from "./spreadsheet-table"
import { SpreadsheetSidebar } from "./spreadsheet-sidebar"
import type { TaskRow, SortState } from "@/types/spreadsheet"

const mockData: TaskRow[] = [
  {
    id: 1,
    jobRequest: "Launch social media campaign for pro...",
    submitted: "15-11-2024",
    status: "In-progress",
    submitter: "Aisha Patel",
    url: "www.aishapatel...",
    assigned: "Sophie Choudhury",
    priority: "Medium",
    dueDate: "30-11-2024",
    estValue: "6,200,000",
  },
  {
    id: 2,
    jobRequest: "Update pricing kit for company redesign",
    submitted: "28-10-2024",
    status: "Complete",
    submitter: "Ifan Khan",
    url: "www.ifankhan...",
    assigned: "Tess Pensley",
    priority: "High",
    dueDate: "30-10-2024",
    estValue: "3,200,000",
  },
  {
    id: 3,
    jobRequest: "Finalize user testing feedback for app...",
    submitted: "05-12-2024",
    status: "In-progress",
    submitter: "Mark Johnson",
    url: "www.markjohns...",
    assigned: "Rachel Lee",
    priority: "Medium",
    dueDate: "10-12-2024",
    estValue: "4,750,000",
  },
  {
    id: 4,
    jobRequest: "Design new features for the website",
    submitted: "10-01-2025",
    status: "Complete",
    submitter: "Emily Green",
    url: "www.emilygreen...",
    assigned: "Tom Wright",
    priority: "Low",
    dueDate: "15-01-2025",
    estValue: "5,900,000",
  },
  {
    id: 5,
    jobRequest: "Prepare financial report for Q4",
    submitted: "25-01-2025",
    status: "Blocked",
    submitter: "Jessica Brown",
    url: "www.jessicabr...",
    assigned: "Kevin Smith",
    priority: "Low",
    dueDate: "30-01-2025",
    estValue: "2,800,000",
  },
]

export function SpreadsheetApp() {
  const [data, setData] = useState<TaskRow[]>(mockData)
  const [filteredData, setFilteredData] = useState<TaskRow[]>(mockData)
  const [searchQuery, setSearchQuery] = useState("")
  const [filters, setFilters] = useState<any>({})
  const [sortState, setSortState] = useState<SortState>({
    column: null,
    direction: "asc",
  })
  const [selectedCell, setSelectedCell] = useState<{ row: number; col: string } | null>(null)
  const [selectedRows, setSelectedRows] = useState<Set<number>>(new Set())
  const [hiddenColumns, setHiddenColumns] = useState<Set<string>>(new Set())
  const [editingCell, setEditingCell] = useState<{ row: number; col: string; value: string } | null>(null)
  const [viewMode, setViewMode] = useState<"grid" | "list" | "compact">("grid")
  const [undoStack, setUndoStack] = useState<TaskRow[][]>([])
  const [redoStack, setRedoStack] = useState<TaskRow[][]>([])

  // Apply filters, search, and sorting
  useEffect(() => {
    let filtered = [...data]

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter((row) =>
        Object.values(row).some((value) => value.toString().toLowerCase().includes(searchQuery.toLowerCase())),
      )
    }

    // Apply column filters
    Object.entries(filters).forEach(([column, values]) => {
      if (Array.isArray(values) && values.length > 0) {
        filtered = filtered.filter((row) => values.includes(row[column as keyof TaskRow] as string))
      }
    })

    // Apply sorting
    if (sortState.column) {
      filtered.sort((a, b) => {
        const aVal = a[sortState.column!]
        const bVal = b[sortState.column!]

        let comparison = 0
        if (typeof aVal === "string" && typeof bVal === "string") {
          comparison = aVal.localeCompare(bVal)
        } else if (typeof aVal === "number" && typeof bVal === "number") {
          comparison = aVal - bVal
        } else {
          comparison = String(aVal).localeCompare(String(bVal))
        }

        return sortState.direction === "asc" ? comparison : -comparison
      })
    }

    setFilteredData(filtered)
  }, [data, searchQuery, filters, sortState])

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case "s":
            e.preventDefault()
            handleSave()
            break
          case "z":
            e.preventDefault()
            if (e.shiftKey) {
              handleRedo()
            } else {
              handleUndo()
            }
            break
          case "a":
            e.preventDefault()
            handleSelectAll()
            break
          case "c":
            if (selectedRows.size > 0) {
              e.preventDefault()
              handleCopy()
            }
            break
          case "v":
            e.preventDefault()
            handlePaste()
            break
        }
      }
      if (e.key === "Delete" && selectedRows.size > 0) {
        handleDeleteRows()
      }
    }

    document.addEventListener("keydown", handleKeyDown)
    return () => document.removeEventListener("keydown", handleKeyDown)
  }, [selectedRows, data])

  const saveToUndoStack = useCallback(() => {
    setUndoStack((prev) => [...prev.slice(-9), [...data]])
    setRedoStack([])
  }, [data])

  const handleUndo = useCallback(() => {
    if (undoStack.length > 0) {
      const previousState = undoStack[undoStack.length - 1]
      setRedoStack((prev) => [...prev, [...data]])
      setData(previousState)
      setUndoStack((prev) => prev.slice(0, -1))
      console.log("Undo performed")
    }
  }, [undoStack, data])

  const handleRedo = useCallback(() => {
    if (redoStack.length > 0) {
      const nextState = redoStack[redoStack.length - 1]
      setUndoStack((prev) => [...prev, [...data]])
      setData(nextState)
      setRedoStack((prev) => prev.slice(0, -1))
      console.log("Redo performed")
    }
  }, [redoStack, data])

  const handleSave = useCallback(() => {
    localStorage.setItem("spreadsheet-data", JSON.stringify(data))
    console.log("Data saved to localStorage")
    alert("Data saved successfully!")
  }, [data])

  const handleSelectAll = useCallback(() => {
    setSelectedRows(new Set(data.map((_, index) => index)))
    console.log("All rows selected")
  }, [data])

  const handleCopy = useCallback(() => {
    const selectedData = Array.from(selectedRows)
      .map((index) => data[index])
      .map((row) => Object.values(row).join("\t"))
      .join("\n")
    navigator.clipboard.writeText(selectedData)
    console.log("Data copied to clipboard")
    alert(`Copied ${selectedRows.size} rows to clipboard`)
  }, [selectedRows, data])

  const handlePaste = useCallback(() => {
    navigator.clipboard.readText().then((text) => {
      console.log("Pasted data:", text)
      alert("Paste functionality - data would be processed here")
    })
  }, [])

  const handleDeleteRows = useCallback(() => {
    if (selectedRows.size === 0) return
    saveToUndoStack()
    const newData = data.filter((_, index) => !selectedRows.has(index))
    setData(newData)
    setSelectedRows(new Set())
    console.log(`Deleted ${selectedRows.size} rows`)
    alert(`Deleted ${selectedRows.size} rows`)
  }, [selectedRows, data, saveToUndoStack])

  const handleSort = useCallback((column: string, direction: "asc" | "desc") => {
    console.log(`Sorting by ${column} ${direction}`)
    setSortState({ column: column as keyof TaskRow, direction })
  }, [])

  const handleFilter = useCallback((newFilters: any) => {
    console.log("Applying filters:", newFilters)
    setFilters(newFilters)
  }, [])

  const handleCellSelect = useCallback((row: number, col: string) => {
    setSelectedCell({ row, col })
    console.log(`Selected cell: Row ${row}, Column ${col}`)
  }, [])

  const handleCellEdit = useCallback(
    (row: number, col: string, value: string) => {
      saveToUndoStack()
      const newData = [...data]
      newData[row] = { ...newData[row], [col]: value }
      setData(newData)
      setEditingCell(null)
      console.log(`Updated cell [${row}, ${col}] to: ${value}`)
    },
    [data, saveToUndoStack],
  )

  const handleColumnToggle = useCallback((column: string) => {
    console.log(`Toggling column visibility: ${column}`)
    setHiddenColumns((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(column)) {
        newSet.delete(column)
      } else {
        newSet.add(column)
      }
      return newSet
    })
  }, [])

  const handleViewModeChange = useCallback((mode: "grid" | "list" | "compact") => {
    setViewMode(mode)
    console.log(`Changed view mode to: ${mode}`)
  }, [])

  const handleBulkAction = useCallback(
    (action: string) => {
      if (selectedRows.size === 0) {
        alert("Please select rows first")
        return
      }

      saveToUndoStack()
      const newData = [...data]

      switch (action) {
        case "mark-complete":
          selectedRows.forEach((index) => {
            newData[index] = { ...newData[index], status: "Complete" }
          })
          break
        case "mark-in-progress":
          selectedRows.forEach((index) => {
            newData[index] = { ...newData[index], status: "In-progress" }
          })
          break
        case "mark-blocked":
          selectedRows.forEach((index) => {
            newData[index] = { ...newData[index], status: "Blocked" }
          })
          break
        case "set-high-priority":
          selectedRows.forEach((index) => {
            newData[index] = { ...newData[index], priority: "High" }
          })
          break
        case "duplicate":
          const duplicates = Array.from(selectedRows).map((index) => ({
            ...newData[index],
            id: Math.max(...newData.map((r) => r.id)) + index + 1,
            jobRequest: `${newData[index].jobRequest} (Copy)`,
          }))
          newData.push(...duplicates)
          break
      }

      setData(newData)
      console.log(`Bulk action ${action} applied to ${selectedRows.size} rows`)
      alert(`Applied ${action} to ${selectedRows.size} rows`)
    },
    [selectedRows, data, saveToUndoStack],
  )

  const handleAction = useCallback(
    (action: string, payload?: any) => {
      console.log(`Action: ${action}`, payload)

      switch (action) {
        case "new-action":
          saveToUndoStack()
          const newTask: TaskRow = {
            id: Math.max(...data.map((r) => r.id)) + 1,
            jobRequest: payload?.title || "New task created",
            submitted: new Date().toLocaleDateString("en-GB"),
            status: "In-progress",
            submitter: "Current User",
            url: "www.example.com",
            assigned: payload?.assigned || "Unassigned",
            priority: payload?.priority || "Medium",
            dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString("en-GB"),
            estValue: "1,000,000",
          }
          setData([...data, newTask])
          alert("New task created!")
          break

        case "import-data":
          if (payload?.file) {
            // Simulate file processing
            console.log("Processing file:", payload.file.name)
            alert(`Importing data from ${payload.file.name}...`)
          }
          break

        case "export-data":
          const format = payload?.format || "csv"
          const headers = Object.keys(data[0] || {}).join(",")
          const rows = filteredData
            .map((row) =>
              Object.values(row)
                .map((v) => `"${v}"`)
                .join(","),
            )
            .join("\n")
          const content = `${headers}\n${rows}`

          const blob = new Blob([content], { type: `text/${format}` })
          const url = URL.createObjectURL(blob)
          const a = document.createElement("a")
          a.href = url
          a.download = `spreadsheet-export.${format}`
          a.click()
          URL.revokeObjectURL(url)
          alert(`Data exported as ${format.toUpperCase()}!`)
          break

        case "share":
          if (navigator.share) {
            navigator.share({
              title: "Spreadsheet Project",
              text: `Sharing ${filteredData.length} tasks from project spreadsheet`,
              url: window.location.href,
            })
          } else {
            navigator.clipboard.writeText(window.location.href)
            alert("Link copied to clipboard!")
          }
          break

        case "print":
          window.print()
          break

        case "refresh-data":
          setData([...mockData])
          setFilters({})
          setSearchQuery("")
          setSortState({ column: null, direction: "asc" })
          alert("Data refreshed!")
          break

        case "bulk-action":
          handleBulkAction(payload?.action)
          break

        default:
          alert(`${action} functionality executed!`)
      }
    },
    [data, filteredData, saveToUndoStack, handleBulkAction],
  )

  // Load data from localStorage on mount
  useEffect(() => {
    const savedData = localStorage.getItem("spreadsheet-data")
    if (savedData) {
      try {
        const parsed = JSON.parse(savedData)
        setData(parsed)
        console.log("Data loaded from localStorage")
      } catch (error) {
        console.error("Error loading saved data:", error)
      }
    }
  }, [])

  return (
    <div className="flex h-screen bg-white overflow-hidden">
      <SpreadsheetSidebar
        onAction={handleAction}
        selectedRows={selectedRows}
        totalRows={data.length}
        onBulkAction={handleBulkAction}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <SpreadsheetHeader onAction={handleAction} />

        <SpreadsheetToolbar
          onSearch={setSearchQuery}
          onFilter={handleFilter}
          onSort={handleSort}
          onColumnToggle={handleColumnToggle}
          onAction={handleAction}
          onViewModeChange={handleViewModeChange}
          hiddenColumns={hiddenColumns}
          data={filteredData}
          viewMode={viewMode}
          selectedRows={selectedRows}
          canUndo={undoStack.length > 0}
          canRedo={redoStack.length > 0}
          onUndo={handleUndo}
          onRedo={handleRedo}
        />

        <SpreadsheetTable
          data={filteredData}
          onCellSelect={handleCellSelect}
          onCellEdit={handleCellEdit}
          onSort={(column) =>
            handleSort(column, sortState.column === column && sortState.direction === "asc" ? "desc" : "asc")
          }
          selectedCell={selectedCell}
          selectedRows={selectedRows}
          onRowSelect={setSelectedRows}
          sortState={sortState}
          hiddenColumns={hiddenColumns}
          viewMode={viewMode}
          editingCell={editingCell}
          onEditingCell={setEditingCell}
        />

        {/* Status Bar */}
        <div className="bg-gray-50 border-t px-6 py-2 text-sm text-gray-600">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <span>
                {filteredData.length} of {data.length} rows
              </span>
              {selectedRows.size > 0 && <span>{selectedRows.size} selected</span>}
              {Object.keys(filters).length > 0 && <span>Filtered</span>}
              {sortState.column && <span>Sorted by {sortState.column}</span>}
            </div>
            <div className="flex items-center space-x-2">
              <span>Ctrl+S: Save</span>
              <span>Ctrl+Z: Undo</span>
              <span>Del: Delete</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
