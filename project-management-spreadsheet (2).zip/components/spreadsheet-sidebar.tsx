"use client"

import type React from "react"
import { useState } from "react"
import {
  ChevronDown,
  ChevronRight,
  FileText,
  Layers,
  Search,
  Plus,
  Settings,
  Trash2,
  Copy,
  Edit3,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Download,
  Upload,
  Share2,
  Archive,
  Star,
  Clock,
  Users,
  X,
} from "lucide-react"

interface SpreadsheetSidebarProps {
  onAction: (action: string, payload?: any) => void
  selectedRows: Set<number>
  totalRows: number
  onBulkAction: (action: string) => void
}

interface Page {
  id: string
  name: string
  isActive: boolean
  isStarred: boolean
  lastModified: string
  createdBy: string
}

interface Layer {
  id: string
  name: string
  icon: string
  isVisible: boolean
  isLocked: boolean
  isActive: boolean
  color: string
  type: "data" | "style" | "component"
}

export function SpreadsheetSidebar({ onAction, selectedRows, totalRows, onBulkAction }: SpreadsheetSidebarProps) {
  const [expandedSections, setExpandedSections] = useState({
    pages: true,
    layers: true,
    properties: false,
    history: false,
    comments: false,
  })

  const [searchQuery, setSearchQuery] = useState("")
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [activeTab, setActiveTab] = useState<"structure" | "properties" | "history">("structure")

  const [pages, setPages] = useState<Page[]>([
    {
      id: "1",
      name: "Page 1",
      isActive: true,
      isStarred: false,
      lastModified: "2 hours ago",
      createdBy: "John Doe",
    },
  ])

  const [layers, setLayers] = useState<Layer[]>([
    {
      id: "1",
      name: "Note",
      icon: "📝",
      isVisible: true,
      isLocked: false,
      isActive: false,
      color: "#3B82F6",
      type: "component",
    },
    {
      id: "2",
      name: "Spreadsheet style",
      icon: "📊",
      isVisible: true,
      isLocked: false,
      isActive: false,
      color: "#10B981",
      type: "style",
    },
    {
      id: "3",
      name: "Working area",
      icon: "🎯",
      isVisible: true,
      isLocked: false,
      isActive: true,
      color: "#F59E0B",
      type: "data",
    },
  ])

  const [projectHistory] = useState([
    { id: "1", action: "Created new task", user: "John Doe", time: "5 minutes ago" },
    { id: "2", action: "Updated status filters", user: "Jane Smith", time: "1 hour ago" },
    { id: "3", action: "Added new column", user: "Mike Johnson", time: "2 hours ago" },
    { id: "4", action: "Exported data", user: "Sarah Wilson", time: "1 day ago" },
  ])

  const [comments] = useState([
    { id: "1", user: "Alice", message: "Great progress on this project!", time: "30 min ago", resolved: false },
    { id: "2", user: "Bob", message: "Need to update the priority levels", time: "2 hours ago", resolved: true },
    { id: "3", user: "Carol", message: "Can we add more filters?", time: "1 day ago", resolved: false },
  ])

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }))
    console.log(`Toggled ${section} section`)
  }

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value)
    console.log("Searching for:", e.target.value)
  }

  const addNewPage = () => {
    const newPage: Page = {
      id: Date.now().toString(),
      name: `Page ${pages.length + 1}`,
      isActive: false,
      isStarred: false,
      lastModified: "Just now",
      createdBy: "Current User",
    }
    setPages([...pages, newPage])
    onAction("page-created", { page: newPage })
    console.log(`Added new page: ${newPage.name}`)
    alert(`Created ${newPage.name}!`)
  }

  const deletePage = (pageId: string) => {
    if (pages.length > 1) {
      const pageToDelete = pages.find((p) => p.id === pageId)
      setPages(pages.filter((p) => p.id !== pageId))
      onAction("page-deleted", { pageId })
      console.log(`Deleted page: ${pageToDelete?.name}`)
      alert(`Deleted ${pageToDelete?.name}!`)
    } else {
      alert("Cannot delete the last page!")
    }
  }

  const duplicatePage = (pageId: string) => {
    const originalPage = pages.find((p) => p.id === pageId)
    if (originalPage) {
      const duplicatedPage: Page = {
        ...originalPage,
        id: Date.now().toString(),
        name: `${originalPage.name} (Copy)`,
        isActive: false,
        lastModified: "Just now",
      }
      setPages([...pages, duplicatedPage])
      onAction("page-duplicated", { originalPage, duplicatedPage })
      alert(`Duplicated ${originalPage.name}!`)
    }
  }

  const togglePageStar = (pageId: string) => {
    setPages(pages.map((page) => (page.id === pageId ? { ...page, isStarred: !page.isStarred } : page)))
    const page = pages.find((p) => p.id === pageId)
    console.log(`${page?.isStarred ? "Unstarred" : "Starred"} page: ${page?.name}`)
  }

  const setActivePage = (pageId: string) => {
    setPages(pages.map((page) => ({ ...page, isActive: page.id === pageId })))
    const activePage = pages.find((p) => p.id === pageId)
    onAction("page-activated", { pageId })
    console.log(`Activated page: ${activePage?.name}`)
  }

  const toggleLayerVisibility = (layerId: string) => {
    setLayers(layers.map((layer) => (layer.id === layerId ? { ...layer, isVisible: !layer.isVisible } : layer)))
    const layer = layers.find((l) => l.id === layerId)
    onAction("layer-visibility-toggled", { layerId, isVisible: !layer?.isVisible })
    console.log(`${layer?.isVisible ? "Hidden" : "Shown"} layer: ${layer?.name}`)
  }

  const toggleLayerLock = (layerId: string) => {
    setLayers(layers.map((layer) => (layer.id === layerId ? { ...layer, isLocked: !layer.isLocked } : layer)))
    const layer = layers.find((l) => l.id === layerId)
    onAction("layer-lock-toggled", { layerId, isLocked: !layer?.isLocked })
    console.log(`${layer?.isLocked ? "Unlocked" : "Locked"} layer: ${layer?.name}`)
  }

  const setActiveLayer = (layerId: string) => {
    setLayers(layers.map((layer) => ({ ...layer, isActive: layer.id === layerId })))
    const activeLayer = layers.find((l) => l.id === layerId)
    onAction("layer-activated", { layerId })
    console.log(`Activated layer: ${activeLayer?.name}`)
  }

  const addNewLayer = () => {
    const newLayer: Layer = {
      id: Date.now().toString(),
      name: `Layer ${layers.length + 1}`,
      icon: "📄",
      isVisible: true,
      isLocked: false,
      isActive: false,
      color: "#6366F1",
      type: "component",
    }
    setLayers([...layers, newLayer])
    onAction("layer-created", { layer: newLayer })
    alert(`Created ${newLayer.name}!`)
  }

  const deleteLayer = (layerId: string) => {
    if (layers.length > 1) {
      const layerToDelete = layers.find((l) => l.id === layerId)
      setLayers(layers.filter((l) => l.id !== layerId))
      onAction("layer-deleted", { layerId })
      alert(`Deleted ${layerToDelete?.name}!`)
    } else {
      alert("Cannot delete the last layer!")
    }
  }

  const handleProjectSettings = () => {
    onAction("project-settings")
    console.log("Project settings opened")
    alert("Project settings panel opened!")
  }

  const handleQuickAction = (action: string) => {
    onAction(action)
    console.log(`Quick action: ${action}`)

    switch (action) {
      case "duplicate-project":
        alert("Project duplicated successfully!")
        break
      case "export-project":
        alert("Project exported successfully!")
        break
      case "archive-project":
        alert("Project archived!")
        break
      case "share-project":
        alert("Project sharing options opened!")
        break
      default:
        alert(`${action} executed!`)
    }
  }

  const filteredPages = pages.filter((page) => page.name.toLowerCase().includes(searchQuery.toLowerCase()))
  const filteredLayers = layers.filter((layer) => layer.name.toLowerCase().includes(searchQuery.toLowerCase()))

  if (isCollapsed) {
    return (
      <div className="w-12 bg-gray-900 text-white flex flex-col items-center py-4">
        <button
          onClick={() => setIsCollapsed(false)}
          className="p-2 hover:bg-gray-700 rounded mb-4"
          title="Expand sidebar"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
        <div className="space-y-2">
          <button className="p-2 hover:bg-gray-700 rounded" title="Pages">
            <FileText className="w-4 h-4" />
          </button>
          <button className="p-2 hover:bg-gray-700 rounded" title="Layers">
            <Layers className="w-4 h-4" />
          </button>
          <button className="p-2 hover:bg-gray-700 rounded" title="Settings">
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="w-80 bg-gray-900 text-white flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
            <span className="font-medium text-sm">Intern Design Assignment</span>
          </div>
          <div className="flex items-center space-x-1">
            <button onClick={handleProjectSettings} className="p-1 hover:bg-gray-700 rounded" title="Project settings">
              <Settings className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsCollapsed(true)}
              className="p-1 hover:bg-gray-700 rounded"
              title="Collapse sidebar"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex space-x-1 mb-4">
          <button
            onClick={() => setActiveTab("structure")}
            className={`px-3 py-1 text-xs rounded ${
              activeTab === "structure" ? "bg-blue-600 text-white" : "bg-gray-700 text-gray-300 hover:bg-gray-600"
            }`}
          >
            Structure
          </button>
          <button
            onClick={() => setActiveTab("properties")}
            className={`px-3 py-1 text-xs rounded ${
              activeTab === "properties" ? "bg-blue-600 text-white" : "bg-gray-700 text-gray-300 hover:bg-gray-600"
            }`}
          >
            Properties
          </button>
          <button
            onClick={() => setActiveTab("history")}
            className={`px-3 py-1 text-xs rounded ${
              activeTab === "history" ? "bg-blue-600 text-white" : "bg-gray-700 text-gray-300 hover:bg-gray-600"
            }`}
          >
            History
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search..."
            value={searchQuery}
            onChange={handleSearch}
            className="w-full bg-gray-800 text-white text-sm px-10 py-2 rounded border border-gray-700 focus:border-blue-500 focus:outline-none"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>

      {/* Content based on active tab */}
      <div className="flex-1 overflow-y-auto">
        {activeTab === "structure" && (
          <>
            {/* Pages Section */}
            <div className="p-4">
              <div className="flex items-center justify-between mb-2">
                <button
                  onClick={() => toggleSection("pages")}
                  className="flex items-center space-x-2 text-sm text-gray-300 hover:text-white"
                >
                  {expandedSections.pages ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                  <FileText className="w-4 h-4" />
                  <span>Pages ({pages.length})</span>
                </button>
                <div className="flex items-center space-x-1">
                  <button
                    onClick={addNewPage}
                    className="text-gray-400 hover:text-white p-1 rounded hover:bg-gray-700"
                    title="Add new page"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => handleQuickAction("import-pages")}
                    className="text-gray-400 hover:text-white p-1 rounded hover:bg-gray-700"
                    title="Import pages"
                  >
                    <Upload className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {expandedSections.pages && (
                <div className="ml-6 space-y-1">
                  {filteredPages.map((page) => (
                    <div
                      key={page.id}
                      className={`group flex items-center justify-between p-2 rounded cursor-pointer ${
                        page.isActive ? "bg-blue-600 text-white" : "hover:bg-gray-700"
                      }`}
                      onClick={() => setActivePage(page.id)}
                    >
                      <div className="flex items-center space-x-2 flex-1 min-w-0">
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            togglePageStar(page.id)
                          }}
                          className="flex-shrink-0"
                        >
                          <Star
                            className={`w-3 h-3 ${page.isStarred ? "text-yellow-400 fill-current" : "text-gray-400"}`}
                          />
                        </button>
                        <span className="text-sm truncate">{page.name}</span>
                      </div>
                      <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100">
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            duplicatePage(page.id)
                          }}
                          className="text-gray-400 hover:text-white p-1"
                          title="Duplicate page"
                        >
                          <Copy className="w-3 h-3" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            const newName = prompt("Enter new page name:", page.name)
                            if (newName) {
                              setPages(pages.map((p) => (p.id === page.id ? { ...p, name: newName } : p)))
                              alert(`Page renamed to: ${newName}`)
                            }
                          }}
                          className="text-gray-400 hover:text-white p-1"
                          title="Rename page"
                        >
                          <Edit3 className="w-3 h-3" />
                        </button>
                        {pages.length > 1 && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation()
                              if (confirm(`Delete page "${page.name}"?`)) {
                                deletePage(page.id)
                              }
                            }}
                            className="text-red-400 hover:text-red-300 p-1"
                            title="Delete page"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Layers Section */}
            <div className="px-4">
              <div className="flex items-center justify-between mb-2">
                <button
                  onClick={() => toggleSection("layers")}
                  className="flex items-center space-x-2 text-sm text-gray-300 hover:text-white"
                >
                  {expandedSections.layers ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                  <Layers className="w-4 h-4" />
                  <span>Layers ({layers.length})</span>
                </button>
                <button
                  onClick={addNewLayer}
                  className="text-gray-400 hover:text-white p-1 rounded hover:bg-gray-700"
                  title="Add new layer"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>

              {expandedSections.layers && (
                <div className="ml-6 space-y-1">
                  {filteredLayers.map((layer) => (
                    <div
                      key={layer.id}
                      className={`group flex items-center justify-between p-2 rounded cursor-pointer ${
                        layer.isActive ? "bg-blue-600 text-white" : "hover:bg-gray-700"
                      }`}
                      onClick={() => setActiveLayer(layer.id)}
                    >
                      <div className="flex items-center space-x-2 flex-1 min-w-0">
                        <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: layer.color }} />
                        <span className="text-xs">{layer.icon}</span>
                        <span className="text-sm truncate">{layer.name}</span>
                        <span className="text-xs text-gray-400 bg-gray-700 px-1 rounded">{layer.type}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            toggleLayerVisibility(layer.id)
                          }}
                          className="text-gray-400 hover:text-white p-1"
                          title={layer.isVisible ? "Hide layer" : "Show layer"}
                        >
                          {layer.isVisible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            toggleLayerLock(layer.id)
                          }}
                          className="text-gray-400 hover:text-white p-1"
                          title={layer.isLocked ? "Unlock layer" : "Lock layer"}
                        >
                          {layer.isLocked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                        </button>
                        {layers.length > 1 && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation()
                              if (confirm(`Delete layer "${layer.name}"?`)) {
                                deleteLayer(layer.id)
                              }
                            }}
                            className="text-red-400 hover:text-red-300 p-1 opacity-0 group-hover:opacity-100"
                            title="Delete layer"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}

        {activeTab === "properties" && (
          <div className="p-4 space-y-4">
            <div>
              <h3 className="text-sm font-medium text-gray-300 mb-2">Project Properties</h3>
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-gray-400">Name</label>
                  <input
                    type="text"
                    defaultValue="Intern Design Assignment"
                    className="w-full bg-gray-800 text-white text-sm px-3 py-2 rounded border border-gray-700 focus:border-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-400">Description</label>
                  <textarea
                    defaultValue="Spreadsheet application for intern assignment"
                    className="w-full bg-gray-800 text-white text-sm px-3 py-2 rounded border border-gray-700 focus:border-blue-500 focus:outline-none h-20 resize-none"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-400">Tags</label>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {["React", "TypeScript", "Spreadsheet"].map((tag) => (
                      <span key={tag} className="bg-blue-600 text-white text-xs px-2 py-1 rounded">
                        {tag}
                      </span>
                    ))}
                    <button className="bg-gray-700 text-gray-300 text-xs px-2 py-1 rounded hover:bg-gray-600">
                      + Add
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-300 mb-2">Data Properties</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Total Rows:</span>
                  <span>{totalRows}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Selected:</span>
                  <span>{selectedRows.size}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Columns:</span>
                  <span>9</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Last Modified:</span>
                  <span>2 hours ago</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-300 mb-2">Permissions</h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Public Access</span>
                  <button className="bg-gray-700 text-white text-xs px-2 py-1 rounded hover:bg-gray-600">
                    Private
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Edit Access</span>
                  <button className="bg-blue-600 text-white text-xs px-2 py-1 rounded hover:bg-blue-700">Owner</button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "history" && (
          <div className="p-4">
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-300 mb-2 flex items-center space-x-2">
                  <Clock className="w-4 h-4" />
                  <span>Recent Activity</span>
                </h3>
                <div className="space-y-2">
                  {projectHistory.map((item) => (
                    <div key={item.id} className="p-2 bg-gray-800 rounded text-sm">
                      <div className="text-white">{item.action}</div>
                      <div className="text-gray-400 text-xs">
                        by {item.user} • {item.time}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium text-gray-300 mb-2 flex items-center space-x-2">
                  <Users className="w-4 h-4" />
                  <span>Comments</span>
                </h3>
                <div className="space-y-2">
                  {comments.map((comment) => (
                    <div key={comment.id} className="p-2 bg-gray-800 rounded text-sm">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-blue-400 font-medium">{comment.user}</span>
                        <span className="text-xs text-gray-400">{comment.time}</span>
                      </div>
                      <div className="text-white text-xs mb-1">{comment.message}</div>
                      <div className="flex items-center space-x-2">
                        <span
                          className={`text-xs px-2 py-0.5 rounded ${
                            comment.resolved ? "bg-green-600 text-white" : "bg-yellow-600 text-white"
                          }`}
                        >
                          {comment.resolved ? "Resolved" : "Open"}
                        </span>
                        <button className="text-xs text-blue-400 hover:text-blue-300">Reply</button>
                      </div>
                    </div>
                  ))}
                </div>
                <button className="w-full mt-2 bg-blue-600 text-white text-sm py-2 rounded hover:bg-blue-700">
                  Add Comment
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer Actions */}
      <div className="p-4 border-t border-gray-700">
        <div className="text-xs text-gray-400 mb-2">Quick Actions</div>
        <div className="grid grid-cols-2 gap-2">
          <button
            className="flex items-center space-x-2 text-sm text-gray-300 hover:text-white py-2 px-3 rounded hover:bg-gray-700"
            onClick={() => handleQuickAction("duplicate-project")}
          >
            <Copy className="w-4 h-4" />
            <span>Duplicate</span>
          </button>
          <button
            className="flex items-center space-x-2 text-sm text-gray-300 hover:text-white py-2 px-3 rounded hover:bg-gray-700"
            onClick={() => handleQuickAction("export-project")}
          >
            <Download className="w-4 h-4" />
            <span>Export</span>
          </button>
          <button
            className="flex items-center space-x-2 text-sm text-gray-300 hover:text-white py-2 px-3 rounded hover:bg-gray-700"
            onClick={() => handleQuickAction("share-project")}
          >
            <Share2 className="w-4 h-4" />
            <span>Share</span>
          </button>
          <button
            className="flex items-center space-x-2 text-sm text-gray-300 hover:text-white py-2 px-3 rounded hover:bg-gray-700"
            onClick={() => handleQuickAction("archive-project")}
          >
            <Archive className="w-4 h-4" />
            <span>Archive</span>
          </button>
        </div>
      </div>
    </div>
  )
}
