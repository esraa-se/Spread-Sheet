export interface TaskRow {
  id: number
  jobRequest: string
  submitted: string
  status: "In-progress" | "Complete" | "Blocked"
  submitter: string
  url: string
  assigned: string
  priority: "Low" | "Medium" | "High"
  dueDate: string
  estValue: string
}

export interface ColumnConfig {
  key: keyof TaskRow
  label: string
  width: string
  sortable: boolean
  filterable: boolean
}

export interface FilterState {
  status: string[]
  priority: string[]
  submitter: string[]
  assigned: string[]
}

export interface SortState {
  column: keyof TaskRow | null
  direction: "asc" | "desc"
}
