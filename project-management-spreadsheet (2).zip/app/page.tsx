import { SpreadsheetApp } from "@/components/spreadsheet-app"

export default function Home() {
  return <SpreadsheetApp />
}
